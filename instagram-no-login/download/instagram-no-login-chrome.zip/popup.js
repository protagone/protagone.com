// The extension pop-up: the fallback site (the script menu of the
// userscript) and the language of the search box. Both are saved in
// storage.local, where the content script reads them and sees changes.

const api = globalThis.browser?.storage ? globalThis.browser : globalThis.chrome;
const viewers = document.getElementById("viewers");
const select = document.getElementById("language");

const show = (viewerName, languageCode) => {
    const t = LANGUAGES[languageCode] || LANGUAGES.en;
    document.documentElement.lang = languageCode;
    document.documentElement.dir = t.rtl ? "rtl" : "ltr";
    document.getElementById("fallback").textContent = t.fallback;
    document.getElementById("fallbackHelp").textContent = t.fallbackHelp;
    document.getElementById("languageLabel").textContent = t.language;
    select.value = languageCode;
    for (const input of viewers.querySelectorAll("input")) input.checked = input.value === viewerName;
};

for (const viewer of VIEWER_LIST) {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "viewer";
    input.value = viewer.name;
    label.append(input, " ", viewer.name);
    viewers.append(label);
}
for (const [code, l] of Object.entries(LANGUAGES)) select.add(new Option(`${l.flag} ${l.name}`, code));

(async () => {
    const saved = await api.storage.local.get(["currentViewer", "language"]);
    // Version 1.0 of the userscript saved the whole viewer object.
    const viewer = VIEWER_LIST.find(v => v.name === (saved.currentViewer?.name ?? saved.currentViewer))?.name ?? DEFAULT_VIEWER;
    let language = LANGUAGES[saved.language] ? saved.language : "en";
    show(viewer, language);

    viewers.addEventListener("change", event => {
        api.storage.local.set({ currentViewer: event.target.value });
    });
    select.addEventListener("change", () => {
        language = select.value;
        api.storage.local.set({ language });
        show(viewers.querySelector("input:checked")?.value ?? viewer, language);
    });
})();
