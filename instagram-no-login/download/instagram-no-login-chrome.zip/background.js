// Fetches search result pages and profile pictures for the content script,
// which may not fetch another site itself (CORS). Only the hosts listed in
// the manifest's host_permissions, without cookies: the search box sends
// the typed name and nothing else.

const api = globalThis.browser?.runtime ? globalThis.browser : globalThis.chrome;
const PAGES = ["https://search.brave.com", "https://html.duckduckgo.com"];
const IMAGES = ["https://imgs.search.brave.com"];
const TIMEOUT_MS = 10000;
const MAX_IMAGE_BYTES = 1024 * 1024;

const get = async (url, allowed) => {
    if (!allowed.includes(new URL(url).origin)) throw new Error("not an allowed host");
    try {
        return await fetch(url, { credentials: "omit", signal: AbortSignal.timeout(TIMEOUT_MS) });
    } catch (e) {
        throw new Error(e?.name === "TimeoutError" ? "timed out" : "network error");
    }
};

const fetchPage = async url => {
    const response = await get(url, PAGES);
    return { status: response.status, body: await response.text() };
};

// The content script cannot show a remote picture on instagram.com (the
// page's Content-Security-Policy), so it gets a data: URL.
const fetchImage = async url => {
    const response = await get(url, IMAGES);
    const type = response.headers.get("content-type") || "";
    if (response.status !== 200 || !type.startsWith("image/")) throw new Error(`image HTTP ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (!bytes.length || bytes.length > MAX_IMAGE_BYTES) throw new Error("image too large or empty");
    let binary = "";
    for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return { dataUrl: `data:${type.split(";")[0]};base64,${btoa(binary)}` };
};

const HANDLERS = { fetchPage, fetchImage };

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!Object.hasOwn(HANDLERS, message?.type) || sender.id !== api.runtime.id) return false;
    HANDLERS[message.type](message.url).then(sendResponse, error => sendResponse({ error: error.message }));
    return true; // answers later
});
